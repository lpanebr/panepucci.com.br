import { defineCollection, z } from 'astro:content';
import { glob } from 'astro/loaders';

const sinapses = defineCollection({
  loader: glob({ pattern: '**/*.{md,mdx}', base: './src/content/sinapses' }),
  schema: z.object({
    title: z.string(),
    description: z.string(),
    date: z.coerce.date(),
    draft: z.boolean().default(false),
  }),
});

export const collections = { sinapses };
