# Continuidade — panepucci.com.br

## Objetivo

Substituir integralmente o conteúdo do repositório `lpanebr/panepucci.com.br` por este projeto Astro e publicar no GitHub Pages.

O usuário autorizou explicitamente sobrescrever todo o conteúdo atual do repositório. O histórico Git deve ser preservado.

## Estado do projeto

- Astro estático com build validado (`npm run build`).
- Página inicial responsiva baseada no protótipo “Sinapses”.
- Imagem histórica `public/neuron.jpg` usada no hero.
- Conteúdo em Markdown em `src/content/sinapses/`.
- Cards inteiros clicáveis, com páginas próprias e navegação por teclado.
- RSS em `/rss.xml`.
- Workflow do GitHub Pages em `.github/workflows/deploy.yml`.
- Domínio configurado no projeto como `https://panepucci.com.br`.

## Publicação sugerida

```bash
unzip panepucci-com-br-astro.zip
cd panepucci-com-br-astro

git clone https://github.com/lpanebr/panepucci.com.br.git repo
cd repo

# O usuário autorizou apagar todo o conteúdo rastreado e não rastreado deste checkout.
find . -mindepth 1 -maxdepth 1 ! -name .git -exec rm -rf {} +
cp -a ../. .
rm -f CONTINUAR-NO-CODEX.md

npm install
npm run build
git add -A
git commit -m "feat: publicar Sinapses com Astro"
git push origin main
```

Depois, verificar no GitHub:

1. `Settings → Pages`.
2. Em **Source**, selecionar **GitHub Actions**.
3. Aguardar o workflow `Deploy to GitHub Pages`.
4. Configurar `panepucci.com.br` como custom domain caso o GitHub não reconheça automaticamente o arquivo `public/CNAME`.
5. Ajustar os registros DNS conforme o GitHub indicar e ativar **Enforce HTTPS**.

## Publicação de novas Sinapses

Criar um Markdown em `src/content/sinapses/`, fazer commit e push para `main`.
